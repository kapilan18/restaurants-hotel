import { type ReactNode, useState } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import {
  ArrowDown,
  ArrowUpRight,
  Clock3,
  MapPin,
  Menu as MenuIcon,
  Navigation,
  Star,
  UtensilsCrossed,
  UsersRound,
  X,
} from 'lucide-react';
import {
  Route,
  Switch,
  useLocation,
  Router as WouterRouter,
} from 'wouter';

const queryClient = new QueryClient();

function Home() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [activeMenu, setActiveMenu] = useState('All');

  const menuItems = [
    {
      name: 'Koodoo special thali',
      detail: 'A generous banana-leaf spread',
      category: 'South Indian',
      featured: true,
      flag: 'House favourite',
    },
    {
      name: 'Mutton biryani',
      detail: 'Slow-cooked, fragrant, deeply spiced',
      category: 'South Indian',
      flag: 'Must try',
    },
    {
      name: 'Ghee roast dosa',
      detail: 'Paper-crisp edges, soft centre',
      category: 'South Indian',
    },
    {
      name: 'Dragon chicken',
      detail: 'A bright, fiery Chinese classic',
      category: 'Chinese',
    },
    {
      name: 'Paneer fried rice',
      detail: 'Wok-tossed with garden vegetables',
      category: 'Chinese',
    },
  ];

  const visibleMenu = activeMenu === 'All'
    ? menuItems
    : menuItems.filter((item) => item.category === activeMenu);

  const scrollTo = (id: string) => {
    document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' });
    setMenuOpen(false);
  };

  return (
    <div className="koodoo-page min-h-[100dvh]">
      <header className="hero" id="top">
        <nav className="nav-shell" aria-label="Main navigation">
          <a href="#top" className="brand-lockup" data-testid="link-brand">
            <span className="brand-mark" aria-hidden="true">K</span>
            <span>
              <span className="brand-name block">Koodoo</span>
              <span className="brand-place mono-font block">Family restaurant · Pudukkottai</span>
            </span>
          </a>
          <div className={`desktop-nav ${menuOpen ? 'open' : ''}`}>
            <a href="#story" onClick={() => setMenuOpen(false)} data-testid="link-our-story">Our story</a>
            <a href="#menu" onClick={() => setMenuOpen(false)} data-testid="link-menu">The menu</a>
            <a href="#visit" onClick={() => setMenuOpen(false)} data-testid="link-visit">Find us</a>
            <button className="nav-visit" onClick={() => scrollTo('visit')} data-testid="button-plan-visit">
              Plan a visit <ArrowUpRight size={15} strokeWidth={1.8} />
            </button>
          </div>
          <button
            className="menu-toggle"
            onClick={() => setMenuOpen((open) => !open)}
            aria-label={menuOpen ? 'Close navigation' : 'Open navigation'}
            aria-expanded={menuOpen}
            data-testid="button-mobile-menu"
          >
            {menuOpen ? <X size={23} /> : <MenuIcon size={23} />}
          </button>
        </nav>

        <img
          className="hero-image"
          src="/koodoo-feast.jpg"
          alt="A generous South Indian feast served on a banana leaf"
          data-testid="img-hero-feast"
        />
        <div className="hero-content">
          <div className="eyebrow mono-font reveal">A table worth gathering around</div>
          <h1 className="display-font reveal reveal-delay">
            Eat well.<br /><em>Stay awhile.</em>
          </h1>
          <p className="hero-copy reveal reveal-delay-2">
            South Indian comfort, Chinese favourites, and the kind of welcome that makes Pudukkottai feel like home.
          </p>
          <div className="hero-actions reveal reveal-delay-2">
            <button className="button-primary" onClick={() => scrollTo('menu')} data-testid="button-explore-menu">
              Explore the menu <ArrowUpRight size={17} />
            </button>
            <button className="button-quiet" onClick={() => scrollTo('visit')} data-testid="button-get-directions-hero">
              Get directions <Navigation size={16} />
            </button>
          </div>
        </div>
        <div className="hero-proof" data-testid="status-dining-rating">
          <Star className="proof-star" size={22} fill="currentColor" strokeWidth={1.2} />
          <span className="proof-score">4.3</span>
          <span className="proof-label">from 2,334 dining reviews</span>
        </div>
        <div className="scroll-cue mono-font" aria-hidden="true">
          <ArrowDown size={16} className="mr-2 inline" /> Take a seat
        </div>
      </header>

      <div className="ticker" aria-label="Restaurant highlights">
        <span>South Indian</span><span className="ticker-dot" />
        <span>Chinese favourites</span><span className="ticker-dot" />
        <span>Made for families</span><span className="ticker-dot" />
        <span>Right here in Pudukkottai</span>
      </div>

      <main>
        <section className="section" id="story">
          <div className="story-grid">
            <div>
              <div className="section-kicker mono-font">01 — Come as you are</div>
              <h2 className="section-title display-font">The best meals are the ones that <em>linger.</em></h2>
              <p className="story-lead">
                Koodoo is the neighbourhood table for big appetites, small celebrations, and every “let’s just eat out today” in between.
              </p>
            </div>
            <div className="story-note">
              <strong>Good food travels far.</strong>
              <span>
                Ours starts with the familiar: a hot dosa, a proper biryani, a wok that knows exactly what to do. Served generously, the way a family would.
              </span>
            </div>
          </div>
        </section>

        <section className="menu-section" id="menu">
          <div className="section">
            <div className="menu-intro">
              <div>
                <div className="section-kicker mono-font">02 — Pick your happy</div>
                <h2 className="section-title display-font">A little bit of <em>everything good.</em></h2>
              </div>
              <p>From slow Sunday lunches to a quick plate after the cinema. Follow your craving.</p>
            </div>

            <div className="menu-tabs" role="tablist" aria-label="Menu categories">
              {['All', 'South Indian', 'Chinese'].map((category) => (
                <button
                  key={category}
                  className={`menu-tab ${activeMenu === category ? 'active' : ''}`}
                  onClick={() => setActiveMenu(category)}
                  role="tab"
                  aria-selected={activeMenu === category}
                  data-testid={`button-menu-tab-${category.toLowerCase().replace(' ', '-')}`}
                >
                  {category}
                </button>
              ))}
            </div>

            <div className="dish-grid" key={activeMenu}>
              {visibleMenu.map((item, index) => (
                <article className="dish-card" key={item.name} data-testid={`card-dish-${index}`}>
                  {item.flag && <span className="dish-flag mono-font">{item.flag}</span>}
                  <span className="dish-index mono-font">0{index + 1}</span>
                  <h3>{item.name}</h3>
                  <p>{item.detail}</p>
                </article>
              ))}
            </div>

            <div className="menu-foot">
              <p>Our menu changes with the market, but the welcome stays the same.</p>
              <button className="button-primary" onClick={() => scrollTo('visit')} data-testid="button-view-location">
                Visit for the full spread <ArrowUpRight size={17} />
              </button>
            </div>
          </div>
        </section>

        <section className="family-band">
          <div className="section family-layout">
            <div>
              <div className="family-stamp" aria-label="Made for every generation">
                <span>Made for<br />every generation</span>
              </div>
            </div>
            <div className="family-copy">
              <div className="section-kicker mono-font">03 — Bring the whole table</div>
              <h2 className="section-title display-font">More elbows, more stories, <em>more sambar.</em></h2>
              <p>
                There is always room for one more at Koodoo. Come with the grandparents, the cousins, the children who will only eat fried rice — we have a plate for every person and a little time for every story.
              </p>
            </div>
          </div>
        </section>

        <section className="quote-band">
          <div className="section quote-layout">
            <div>
              <div className="section-kicker mono-font">04 — From our table</div>
              <div className="quote-mark" aria-hidden="true">“</div>
            </div>
            <div>
              <blockquote className="quote">“A warm, filling place for a family dinner. The food comes generous and the service feels genuinely kind.”</blockquote>
              <div className="quote-attribution mono-font">— A familiar voice from Pudukkottai</div>
            </div>
          </div>
        </section>

        <section className="section visit-section" id="visit">
          <div className="visit-card">
            <div className="visit-content">
              <div className="section-kicker mono-font">05 — Your table is here</div>
              <h2 className="display-font">See you<br /><em>tonight?</em></h2>
              <p className="visit-address">
                TS 9953/2 Thirumayam Road,<br />
                opposite RKP Theater,<br />
                Pudukkottai Locality, Pudukkottai
              </p>
              <div className="visit-meta">
                <div>
                  <Clock3 size={17} className="mb-2 text-[#f2cf67]" />
                  <strong>Open for dine-in</strong>
                  <span>Come hungry, leave happy</span>
                </div>
                <div>
                  <UsersRound size={17} className="mb-2 text-[#f2cf67]" />
                  <strong>Family friendly</strong>
                  <span>Room for your whole crew</span>
                </div>
              </div>
              <a
                className="button-primary"
                href="https://www.google.com/maps/search/?api=1&query=Koodoo+Family+Restaurant%2C+TS+9953%2F2+Thirumayam+Road%2C+Pudukkottai"
                target="_blank"
                rel="noreferrer"
                data-testid="link-google-maps"
              >
                Open in Google Maps <ArrowUpRight size={17} />
              </a>
            </div>
            <div className="map-panel" aria-label="Stylised map showing Koodoo Family Restaurant opposite RKP Theater">
              <div className="map-road" />
              <div className="map-pin"><MapPin size={28} /></div>
              <div className="map-label">Koodoo · Thirumayam Road</div>
            </div>
          </div>
        </section>
      </main>

      <footer className="footer">
        <div>
          <div className="footer-brand">Koodoo.</div>
          <p>Good food. Full tables. Pudukkottai, always.</p>
        </div>
        <div className="footer-right">
          <div className="mono-font">TS 9953/2 Thirumayam Road · opposite RKP Theater</div>
          <a href="#top" data-testid="link-back-to-top">Back to top ↑</a>
        </div>
      </footer>
    </div>
  );
}

function Router() {
  return (
    // Keep a shared shell (sidebar, navbar) outside the boundary so it
    // survives a page crash.
    <RoutedErrorBoundary>
      <Switch>
        <Route path="/" component={Home} />
        <Route component={NotFound} />
      </Switch>
    </RoutedErrorBoundary>
  );
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
